import pathlib

PROJECT_PATH = pathlib.Path(__file__).absolute().parent.parent
